<template>
    <p class="has-text-centered">
    <font color="#5f89ff">
    请选择您要决策的大运:
    </font>
    
  <br>
  </p>
    <div class="dayun-card">
        
        <div :class="currentIndex==0?'dayun-card-unit-active':'dayun-card-unit'" @click="select(0)">
        {{ props.dayunArr.one.split(' ')[0] }} &nbsp; {{ props.dayunArr.one.split(' ')[2] }} &nbsp; {{ props.dayunArr.one.split(' ')[4] }}
        </div>
        <div :class="currentIndex==1?'dayun-card-unit-active':'dayun-card-unit'" @click="select(1)">
            {{ props.dayunArr.two.split(' ')[0] }} &nbsp; {{ props.dayunArr.two.split(' ')[2] }} &nbsp; {{ props.dayunArr.two.split(' ')[4] }}

        </div>
        <div :class="currentIndex==2?'dayun-card-unit-active':'dayun-card-unit'" @click="select(2)">
            {{ props.dayunArr.three.split(' ')[0] }} &nbsp; {{ props.dayunArr.three.split(' ')[2] }} &nbsp; {{ props.dayunArr.three.split(' ')[4] }}
        </div>
        <div :class="currentIndex==3?'dayun-card-unit-active':'dayun-card-unit'" @click="select(3)">
            {{ props.dayunArr.four.split(' ')[0] }} &nbsp; {{ props.dayunArr.four.split(' ')[2] }} &nbsp; {{ props.dayunArr.four.split(' ')[4] }}


        </div>
        <div :class="currentIndex==4?'dayun-card-unit-active':'dayun-card-unit'" @click="select(4)">
            {{ props.dayunArr.five.split(' ')[0] }} &nbsp; {{ props.dayunArr.five.split(' ')[2] }} &nbsp; {{ props.dayunArr.five.split(' ')[4] }}


        </div>
        <div :class="currentIndex==5?'dayun-card-unit-active':'dayun-card-unit'" @click="select(5)">
            {{ props.dayunArr.six.split(' ')[0] }} &nbsp; {{ props.dayunArr.six.split(' ')[2] }} &nbsp; {{ props.dayunArr.six.split(' ')[4] }}


        </div>
        <div :class="currentIndex==6?'dayun-card-unit-active':'dayun-card-unit'" @click="select(6)">
            {{ props.dayunArr.seven.split(' ')[0] }} &nbsp; {{ props.dayunArr.seven.split(' ')[2] }} &nbsp; {{ props.dayunArr.seven.split(' ')[4] }}


        </div>
        <div :class="currentIndex==7?'dayun-card-unit-active':'dayun-card-unit'" @click="select(7)">
            {{ props.dayunArr.eight.split(' ')[0] }} &nbsp; {{ props.dayunArr.eight.split(' ')[2] }} &nbsp; {{ props.dayunArr.eight.split(' ')[4] }}


        </div>
        <div :class="currentIndex==8?'dayun-card-unit-active':'dayun-card-unit'" @click="select(8)">
            {{ props.dayunArr.nine.split(' ')[0] }} &nbsp; {{ props.dayunArr.nine.split(' ')[2] }} &nbsp; {{ props.dayunArr.nine.split(' ')[4] }}


        </div>
        <div :class="currentIndex==9?'dayun-card-unit-active':'dayun-card-unit'" @click="select(9)">
            {{ props.dayunArr.ten.split(' ')[0] }} &nbsp; {{ props.dayunArr.ten.split(' ')[2] }} &nbsp; {{ props.dayunArr.ten.split(' ')[4] }}

        </div>
    </div>


</template> 

<script setup>
import { computed, ref, watch, reactive } from 'vue'
import MyItem from './MyItem.vue'

const currentIndex = ref(10);
const dayunArr=ref(
    {
      one: "1岁~18岁  [1991年-2000年]  丙辰",
      two: "19岁~28岁  [2001年-2010年]  丁巳",
      three: "29岁~38岁  [2011年-2020年]  戊午",
      four: "39岁~48岁  [2021年-2030年]  己未",
      five: "49岁~58岁  [2031年-2040年]  庚申",
      six: "59岁~68岁  [2041年-2050年]  辛酉",
      seven: "69岁~78岁  [2051年-2060年]  壬戌",
      eight: "79岁~88岁  [2061年-2070年]  癸亥",
      nine: "89岁~98岁  [2071年-2080年]  甲子",
      ten: "99岁~108岁  [2081年-2090年]  乙丑",
    }
);
const props = defineProps({
  //子组件接收父组件传递过来的值
  dayunArr:undefined,
})
const select = (index) => {
    currentIndex.value=index;
    emit("getValue", currentIndex);
}
const emit = defineEmits(["getValue"])

</script>

<style scoped>

.dayun-card {
    padding: 10px 10px 10px 10px;
    width: 390px;
    height:440px;
    border-radius: 30px;
    background: #eaf8ff;
    margin: 0 auto;
    text-align: center;
}
.dayun-card-unit{
    width: 360px;
    font-size: 20px;
    font-weight:500;
    color: rgb(98, 97, 97);
    background-color: #eaf8ff;
    height: 40px;
    border-radius: 50px;
    margin-top: 2px;
    margin-left: 6px;
    padding-top: 3px;
}
.dayun-card-unit:hover {
    background-color: aquamarine;
    border: 1px dashed rgb(0, 0, 0);
    margin-top: 2px;
    margin-left: 6px;

}


.dayun-card-unit-active{
    color: white;
    width: 360px;
    font-size: 20px;
    background-color: #bdbfff;
    height: 40px;
    border-radius: 50px;
    border: 1px dashed rgb(0, 0, 0);
    margin-left: 6px;
    margin-top: 2px;
    padding-top: 3px;

}
</style>